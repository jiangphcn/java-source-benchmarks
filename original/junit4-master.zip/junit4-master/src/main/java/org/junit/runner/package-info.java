/**
 * Provides classes used to describe, collect, run and analyze multiple tests.
 *
 * @since 4.0
 */
package org.junit.runner;