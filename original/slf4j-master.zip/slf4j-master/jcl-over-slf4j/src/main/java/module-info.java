module org.apache.commons.logging {
  requires org.slf4j;
  exports org.apache.commons.logging;
}
